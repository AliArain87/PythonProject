from faulthandler import disable
from msilib.schema import Billboard
from turtle import delay, position
from matplotlib import scale
from scipy import rand
from ursina import *
from ursina.shaders import lit_with_shadows_shader
import random
app = Ursina()
foodCount= []
enemyCount=[]
HealthsBlock=[]
score=0
score_text=Text(text=f'Score: {score}', position=(-0.4,0.44), color=color.dark_text, scale=2.5 )
def change_texture():
    for i in enemyCount:
        i.texture='food.png'

def reload():
    application.hot_reloader.reload_code()


def Play():
    player.disable()
    def start():
        player.enable()
        PlayButton.disable()
    PlayButton= Button(icon='play.png', scale=0.3, position=(0,0), color=color.white10)
    PlayButton.on_click= start

class Enemy(Entity):
    def __init__(self):
        super().__init__()
        self.model='sphere'
        self.collider='sphere'
        self.parent=board
        self.position=(random.uniform(-0.47, 0.47), 2.5, random.uniform(-0.47, 0.47))
        self.texture='food.png'
        self.scale=0.05
        self.scale_y=5

    def update(self):
        self.rotation_y+=1



class Food(Entity):
    def __init__(self):
        super().__init__()
        self.parent=board
        self.model='sphere'
        self.scale=0.05
        self.scale_y=5
        self.texture='food.png'
        self.collider='sphere'
        self.position=(random.uniform(-0.47, 0.47), 2.5, random.uniform(-0.47, 0.47))
        self.shader=lit_with_shadows_shader
    def update(self):
        self.rotation_y+=1
        

class HealthBar(Entity):
    def __init__(self):
        super().__init__()
        self.model='quad'
        self.texture='health.png'
        self.scale=0.1
        self.position=(0.02 , 0.5)
        self.parent=camera.ui

    def update(self):
        try:
            for i in HealthsBlock[player.health:]:
                destroy(i)
        except:
            pass 


class GameOver(Entity):
    def __init__(self):
        super().__init__()
        self.parent= camera.ui
        self.model='quad'
        self.texture='over.png'
        self.scale=0
        
    
    def update(self):
        if self.scale_x<1.5 and self.scale_y<1:
            self.scale_x+=0.01
            self.scale_y+=0.01

class Snake(Entity):
    def __init__(self):
        super().__init__()
        self.parent=board
        self.scale=0.05
        self.scale_y=5
        self.model='sphere'
        self.collider='sphere'
        self.position=(0,2.5,0)
        self.dx=0
        self.dz=0
        self.speed=0.3
        self.texture='head.png'
        self.body=[]
        self.shader=lit_with_shadows_shader
        self.health=3
        self.EnemyEaten=0

    def update(self):
        global score
        self.x+=self.dx*time.dt
        self.z+=self.dz*time.dt
        if self.health<=0:
            for i in player.body:
                i.disable()
            player.disable()
            for i in enemyCount:
                i.fade_out()
            GameOver()
            reload= Button(icon='replay.png', scale=0.3, position=(-0.5, 0.06), color=color.white10)
            reload.on_click= reload
        if self.x > 0.47:
            self.x=-self.x+0.01
        if self.z > 0.47:
            self.z=-self.z+0.01
        if self.z < -0.47:
            self.z=-self.z-0.01
        if self.x < -0.47:
            self.x=-self.x-0.01

        for i in foodCount:
            if self.intersects(i).hit:
                Audio('eat.mp3')
                i.position=(random.uniform(-0.47,0.47), 2.5, random.uniform(-0.47,0.47)) 
                a=Entity(model='sphere', texture='body.png', scale=0.04, scale_y=4, parent=board, Collider= 'sphere', position= (0,2.5,0),
                shader=lit_with_shadows_shader
                )
                self.body.append(a)
                score+=1
                score_text.text= f"Score: {score}"
                self.speed+=0.001
        for i in range(len(self.body)-1,0,-1):
            self.body[i].position= self.body[i-1].position
        if len(self.body)>0:
            self.body[0].position= self.position
        for i in enemyCount:
            if self.intersects(i).hit:
                Audio('eat.mp3')
                i.texture='enemy_red.png'
                invoke(change_texture, delay=1)
                self.EnemyEaten+=1
                if self.EnemyEaten>1:
                    self.health-=1
                i.position=(random.uniform(-0.47,0.47), 2.5, random.uniform(-0.47,0.47))

    def input(self, key):
        if key=='right arrow':
            self.dx=self.speed
            self.dz=0
            self.rotation_y=50
        if key=='left arrow':
            self.dx=-self.speed
            self.dz=0
            self.rotation_y=120
        if key=='up arrow':
            self.dx=0
            self.dz=self.speed
            self.rotation_y=150    
        if key=='down arrow':
            self.dx=0
            self.dz=-self.speed
            self.rotation_y=30
        

board= Entity(model='cube', scale=10, texture='bg2.JPG', scale_y=0.1, Shader=lit_with_shadows_shader)
DirectionalLight(y=2.5, z=2, rotation= (45,-45,45))
# EditorCamera()
Sky(texture='sky.png')
camera.position=(0,12,-15)
camera.rotation=(39,0,0)
player=Snake()

for i in range(3):
    food= Food()
    foodCount.append(food)
for i in range(1):
    enemy=Enemy()
    enemyCount.append(enemy)

offset=0.02
for i in range(player.health):
    healthB= HealthBar()
    healthB.position=(offset, 0.42)
    offset+=0.09
    HealthsBlock.append(healthB)
for i in range(20):
    a=Entity(model='sphere', 
        texture='body.png', 
        scale=0.04, 
        scale_y=4, 
        parent=board, 
        Collider= 'sphere',   
        position= (0,2.5,0),
        shader=lit_with_shadows_shader
        )
    player.body.append(a)
Play()
app.run()